package ng.seller.customer.adapters
import android.view.*; import android.widget.*; import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import ng.seller.customer.R; import ng.seller.customer.models.Product
import java.util.Locale
class ProductAdapter(private val products:List<Product>,private val click:(Product)->Unit):RecyclerView.Adapter<ProductAdapter.VH>(){
    class VH(v:View):RecyclerView.ViewHolder(v){
        val image:ImageView=v.findViewById(R.id.productImage);val name:TextView=v.findViewById(R.id.productName)
        val price:TextView=v.findViewById(R.id.productPrice);val meta:TextView=v.findViewById(R.id.productMeta)
    }
    override fun onCreateViewHolder(p:ViewGroup,t:Int)=VH(LayoutInflater.from(p.context).inflate(R.layout.item_product,p,false))
    override fun getItemCount()=products.size
    override fun onBindViewHolder(h:VH,pos:Int){val p=products[pos];h.name.text=p.name
        h.price.text=String.format(Locale.US,"₦%,.0f",p.currentPrice)
        h.meta.text="⭐ %.1f • %d sold%s".format(p.ratingAvg,p.sold,if(p.stock>0) " • ${p.stock} left" else " • Out of stock")
        Glide.with(h.image.context).load(p.imageUrl).placeholder(android.R.drawable.ic_menu_gallery).error(android.R.drawable.ic_menu_report_image).into(h.image)
        h.itemView.setOnClickListener{click(p)}
    }
}
