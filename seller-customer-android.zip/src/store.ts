import AsyncStorage from "@react-native-async-storage/async-storage";
export type Product={id:number;name:string;slug?:string;description?:string;image_url?:string;current_price:number|string;old_price?:number|string;stock:number;sold:number;rating:number;reviews_count:number;category?:number;category_name?:string;source_shop?:any};
export type CartLine={id:number;name:string;price:number;qty:number;image_url?:string};
const CART="seller_cart";
export async function getCart():Promise<CartLine[]>{try{return JSON.parse(await AsyncStorage.getItem(CART)||"[]")}catch{return[]}}
export async function saveCart(c:CartLine[]){await AsyncStorage.setItem(CART,JSON.stringify(c))}
export async function addCart(p:Product){const c=await getCart();const x=c.find(v=>v.id===p.id);if(x)x.qty++;else c.push({id:p.id,name:p.name,price:Number(p.current_price),qty:1,image_url:p.image_url});await saveCart(c)}
export async function removeCart(id:number){await saveCart((await getCart()).filter(x=>x.id!==id))}
