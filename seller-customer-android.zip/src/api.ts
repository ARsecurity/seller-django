import AsyncStorage from "@react-native-async-storage/async-storage";
export const API="https://seller-zamfara-api.onrender.com";
export async function token(){return AsyncStorage.getItem("token");}
export async function api<T>(path:string, options:RequestInit={}, auth=true):Promise<T>{
 const t=auth?await token():null;
 const headers:any={"Content-Type":"application/json",...(options.headers||{})};
 if(t) headers.Authorization=`Token ${t}`;
 const r=await fetch(`${API}/api/${path}`,{...options,headers});
 const text=await r.text();
 let data:any={}; try{data=text?JSON.parse(text):null}catch{}
 if(!r.ok) throw new Error(data?.detail||"Request failed");
 return data as T;
}
export const money=(n:any)=>`₦${Number(n||0).toLocaleString("en-NG")}`;
