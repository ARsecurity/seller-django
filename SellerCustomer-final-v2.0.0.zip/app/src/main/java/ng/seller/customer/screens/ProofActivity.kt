package ng.seller.customer.screens
import android.os.Bundle
import ng.seller.customer.*
import org.json.JSONObject
class ProofActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val ref=intent.getStringExtra("ref")?:"";val r=root("Payment Proof");val bank=input("Bank used");val sender=input("Sender name");val tx=input("Transaction reference")
 r.addView(text("Order: $ref"));r.addView(bank);r.addView(sender);r.addView(tx);r.addView(button("Submit Proof"){val t=SessionStorage.token(this);if(t==null){toast("Login required");return@button};val body=JSONObject().put("bank",bank.text.toString()).put("sender_name",sender.text.toString()).put("transaction_ref",tx.text.toString()).toString();ApiClient.post("orders/$ref/proof/",body,t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{toast("Proof submitted");finish()}};override fun onError(e:String){runOnUiThread{toast(e)}}})});setContentView(r)}
}
