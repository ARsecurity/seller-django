#!/usr/bin/env bash
set -e
export JAVA_HOME="${JAVA_HOME:-$HOME/.sdkman/candidates/java/17.0.20+1-ms}"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Install Gradle 8.9+ in the Codespace, then rerun."
  exit 1
fi
gradle wrapper --gradle-version 8.9
./gradlew clean
./gradlew assembleDebug
echo "Build complete: app/build/outputs/apk/debug/app-debug.apk"
