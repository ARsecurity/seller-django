package ng.seller.customer.screens
import android.os.Bundle
import android.widget.*
import ng.seller.customer.*
import org.json.*
class CheckoutActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val r=root("Checkout");val t=SessionStorage.token(this);if(t==null){r.addView(button("Login to Checkout"){startActivity(android.content.Intent(this,LoginActivity::class.java))});setContentView(r);return}
 val addresses=mutableListOf<JSONObject>();val lga=input("LGA ID");val addr=input("Delivery address");val phone=input("Phone");val method=Spinner(this);method.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("cod","transfer"))
 r.addView(text("Enter your delivery details"));r.addView(lga);r.addView(addr);r.addView(phone);r.addView(text("Payment method"));r.addView(method)
 ApiClient.get("addresses/",t,object:ApiClient.Callback{override fun onSuccess(x:String){val a=JSONArray(x);for(i in 0 until a.length())addresses.add(a.getJSONObject(i));runOnUiThread{if(addresses.isNotEmpty()){val o=addresses[0];lga.setText(o.optString("lga"));addr.setText(o.optString("address"));phone.setText(o.optString("phone"))}}};override fun onError(e:String){}})
 r.addView(button("Place Order"){val items=JSONArray();CartStorage.items(this).forEach{items.put(JSONObject().put("product",it.product.id).put("qty",it.qty))};val body=JSONObject().put("lga",lga.text.toString().toIntOrNull()).put("address",addr.text.toString()).put("phone",phone.text.toString()).put("method",method.selectedItem.toString()).put("items_in",items).toString();ApiClient.post("orders/",body,t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{CartStorage.clear(this@CheckoutActivity);toast("Order placed");finish()}};override fun onError(e:String){runOnUiThread{toast(e)}}})});setContentView(r)}
}
