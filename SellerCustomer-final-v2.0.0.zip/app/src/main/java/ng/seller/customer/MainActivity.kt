package ng.seller.customer
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ng.seller.customer.adapters.ProductAdapter
import ng.seller.customer.screens.*
class MainActivity:AppCompatActivity(){
    private lateinit var status:TextView; private lateinit var recycler:RecyclerView
    private var all=emptyList<ng.seller.customer.models.Product>()
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
        status=findViewById(R.id.homeStatus);recycler=findViewById(R.id.productRecycler)
        recycler.layoutManager=GridLayoutManager(this,2)
        findViewById<Button>(R.id.cartButton).setOnClickListener{startActivity(Intent(this,CartActivity::class.java))}
        findViewById<Button>(R.id.ordersButton).setOnClickListener{startActivity(Intent(this,OrdersActivity::class.java))}
        findViewById<Button>(R.id.accountButton).setOnClickListener{startActivity(Intent(this,AccountActivity::class.java))}
        findViewById<EditText>(R.id.searchInput).addTextChangedListener(SimpleTextWatcher{filter(it)})
        load()
    }
    override fun onResume(){super.onResume(); updateStatus()}
    private fun load(){status.text="Loading products..."
        ApiClient.get("home/",null,object:ApiClient.Callback{
            override fun onSuccess(r:String){runOnUiThread{try{val h=JsonParser.home(r);all=(h.deals+h.trending).distinctBy{it.id};show(all);updateStatus()}catch(e:Exception){status.text="Unable to read products";toast(e.message)}}}
            override fun onError(e:String){runOnUiThread{status.text="Unable to load products";toast(e)}}
        })
    }
    private fun filter(q:String){show(if(q.isBlank())all else all.filter{it.name.contains(q,true)||it.description.contains(q,true)})}
    private fun show(list:List<ng.seller.customer.models.Product>){recycler.adapter=ProductAdapter(list){p->startActivity(Intent(this,ProductDetailActivity::class.java).putExtra("product_id",p.id))};status.text="${list.size} products"}
    private fun updateStatus(){findViewById<Button>(R.id.cartButton).text="Cart (${CartStorage.count(this)})"}
    private fun toast(s:String?){Toast.makeText(this,s?:"Error",Toast.LENGTH_LONG).show()}
}
class SimpleTextWatcher(private val f:(String)->Unit):android.text.TextWatcher{
    override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){f(s?.toString()?:"")}
    override fun afterTextChanged(e:android.text.Editable?){}
}
