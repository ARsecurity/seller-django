package ng.seller.customer.screens
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
open class BaseScreen:AppCompatActivity(){
    fun root(title:String):LinearLayout{val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(16,16,16,16)
        val t=TextView(this);t.text=title;t.textSize=24f;t.setTextColor(Color.BLACK);t.setTypeface(null,1);r.addView(t,LinearLayout.LayoutParams(-1,-2));return r}
    fun button(text:String,click:()->Unit)=Button(this).apply{this.text=text;setOnClickListener{click()}}
    fun input(hint:String)=EditText(this).apply{this.hint=hint;setPadding(10,10,10,10)}
    fun text(s:String,size:Float=15f)=TextView(this).apply{text=s;textSize=size;setPadding(0,8,0,8)}
    fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
