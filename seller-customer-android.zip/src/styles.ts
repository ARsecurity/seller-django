import {StyleSheet} from "react-native";
export const C={green:"#0b7a43",light:"#f4f8f5",cream:"#fffaf1",orange:"#ff6b00",text:"#18231d",muted:"#718078",border:"#e5ebe7",white:"#fff"};
export const S=StyleSheet.create({
 screen:{flex:1,backgroundColor:C.light},container:{paddingHorizontal:14},title:{fontSize:24,fontWeight:"900",color:C.text},muted:{color:C.muted},section:{marginTop:18},row:{flexDirection:"row",alignItems:"center",justifyContent:"space-between"},
 card:{backgroundColor:C.white,borderRadius:14,padding:10,borderWidth:1,borderColor:C.border},
 button:{backgroundColor:C.green,borderRadius:12,paddingVertical:14,alignItems:"center"},buttonText:{color:C.white,fontWeight:"900",fontSize:16},
 input:{backgroundColor:C.white,borderWidth:1,borderColor:C.border,borderRadius:12,padding:13,fontSize:16},badge:{position:"absolute",right:7,top:7,backgroundColor:C.orange,paddingHorizontal:7,paddingVertical:4,borderRadius:8},
});
