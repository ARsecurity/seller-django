package ng.seller.customer.screens
import android.content.Intent
import android.os.Bundle
import ng.seller.customer.*
import org.json.JSONObject
class LoginActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val r=root("Login");val u=input("Username");val p=input("Password");p.inputType=129
 r.addView(u);r.addView(p);r.addView(button("Login"){val body=JSONObject().put("username",u.text.toString().trim()).put("password",p.text.toString()).toString()
 ApiClient.post("auth/login/",body,null,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{SessionStorage.saveToken(this@LoginActivity,JSONObject(x).getString("token"));toast("Logged in");finish()}};override fun onError(e:String){runOnUiThread{toast(e)}}})})
 r.addView(button("Create account"){startActivity(Intent(this,RegisterActivity::class.java))});r.addView(button("Forgot password"){toast("Use the password reset endpoint from the web account flow.")});setContentView(r)}
}
