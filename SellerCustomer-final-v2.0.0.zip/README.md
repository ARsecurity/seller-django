# Seller Customer Android v2.0.0

Native Kotlin/XML customer application for the Seller marketplace.

Backend:
https://seller-zamfara-api.onrender.com/api/

Build requirements:
- Android SDK 35
- JDK 17
- Gradle 8.9+
- Android 10+ (minSdk 29)

From the project directory:
    gradle wrapper --gradle-version 8.9
    ./gradlew clean assembleRelease

The release APK is generated at:
app/build/outputs/apk/release/app-release.apk

This source is intended to be uploaded to GitHub and built in Codespaces.
Do not commit secrets or API credentials.
