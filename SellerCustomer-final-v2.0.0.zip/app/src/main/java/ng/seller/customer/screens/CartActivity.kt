package ng.seller.customer.screens
import android.content.Intent
import android.os.Bundle
import android.widget.*
import ng.seller.customer.CartStorage
import java.util.Locale
class CartActivity:BaseScreen(){
    override fun onCreate(b:Bundle?){super.onCreate(b);render()}
    override fun onResume(){super.onResume();render()}
    private fun render(){val r=root("Your Cart");val scroll=ScrollView(this);val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL
        val lines=CartStorage.items(this);if(lines.isEmpty()){box.addView(text("Your cart is empty"));box.addView(button("Continue Shopping"){finish()})}else{
            var total=0.0
            lines.forEach{line->total+=line.product.currentPrice*line.qty
                val row=LinearLayout(this);row.orientation=LinearLayout.VERTICAL;row.setPadding(0,8,0,8)
                row.addView(text("${line.product.name}\n₦${String.format(Locale.US,"%,.0f",line.product.currentPrice)} × ${line.qty}"))
                val controls=LinearLayout(this)
                controls.addView(button("-"){CartStorage.setQty(this,line.product.id,line.qty-1);render()})
                controls.addView(button("+"){CartStorage.setQty(this,line.product.id,minOf(line.product.stock,line.qty+1));render()})
                controls.addView(button("Remove"){CartStorage.remove(this,line.product.id);render()})
                row.addView(controls);box.addView(row)
            }
            box.addView(text("Subtotal: ₦${String.format(Locale.US,"%,.0f",total)}",20f))
            box.addView(button("Checkout"){startActivity(Intent(this,CheckoutActivity::class.java))})
            box.addView(button("Clear Cart"){CartStorage.clear(this);render()})
        };scroll.addView(box);r.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(r)}
}
