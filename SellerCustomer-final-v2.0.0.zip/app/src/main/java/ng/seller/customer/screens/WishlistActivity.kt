package ng.seller.customer.screens
import android.content.Intent
import android.os.Bundle
import ng.seller.customer.*
import org.json.JSONArray
class WishlistActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val r=root("Wishlist");val t=SessionStorage.token(this);if(t==null){toast("Login required");finish();return}
 ApiClient.get("wishlist/",t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{val a=JSONArray(x);if(a.length()==0)r.addView(text("No wishlist items"));for(i in 0 until a.length()){val p=JsonParser.product(a.getJSONObject(i));r.addView(button("${p.name} • ₦${p.currentPrice.toInt()}"){startActivity(Intent(this,ProductDetailActivity::class.java).putExtra("product_id",p.id))})}}};override fun onError(e:String){runOnUiThread{toast(e)}}});setContentView(r)}
}
