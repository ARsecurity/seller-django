# Seller Customer Android App

React Native + Expo customer app for the existing Seller Django API.

API: https://seller-zamfara-api.onrender.com

The app uses the same backend as the web marketplace. Admin/product/order data remains in Django/Neon.

## Build
npm install
npx expo start

For an installable Android APK, configure EAS and run:
npx eas-cli@latest build --platform android --profile preview

For Google Play:
npx eas-cli@latest build --platform android --profile production
