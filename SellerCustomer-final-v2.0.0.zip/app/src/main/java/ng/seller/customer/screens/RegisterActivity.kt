package ng.seller.customer.screens
import android.os.Bundle
import ng.seller.customer.*
import org.json.JSONObject
class RegisterActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val r=root("Create Account");val u=input("Username");val e=input("Email (optional)");val p=input("Password (8+ characters)");p.inputType=129
 r.addView(u);r.addView(e);r.addView(p);r.addView(button("Register"){val body=JSONObject().put("username",u.text.toString().trim()).put("email",e.text.toString().trim()).put("password",p.text.toString()).toString()
 ApiClient.post("auth/register/",body,null,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{SessionStorage.saveToken(this@RegisterActivity,JSONObject(x).getString("token"));toast("Account created");finish()}};override fun onError(er:String){runOnUiThread{toast(er)}}})});setContentView(r)}
}
