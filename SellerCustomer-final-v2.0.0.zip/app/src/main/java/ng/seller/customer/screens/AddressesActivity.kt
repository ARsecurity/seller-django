package ng.seller.customer.screens
import android.os.Bundle
import android.widget.*
import ng.seller.customer.*
import org.json.*
class AddressesActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);load()}
 private fun load(){val r=root("My Addresses");val t=SessionStorage.token(this);if(t==null){toast("Login required");finish();return}
 ApiClient.get("addresses/",t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{val a=JSONArray(x);for(i in 0 until a.length()){val o=a.getJSONObject(i);r.addView(text("${o.optString("first_name")} ${o.optString("last_name")}\n${o.optString("phone")}\n${o.optString("address")}\n${o.optString("lga_name")}"))};r.addView(button("Add Address"){addForm(r,t)})}};override fun onError(e:String){runOnUiThread{toast(e);r.addView(button("Add Address"){addForm(r,t)})}}});setContentView(r)}
 private fun addForm(r:LinearLayout,t:String){val f=root("New Address");val first=input("First name");val last=input("Last name");val phone=input("Phone");val address=input("Address");val lga=input("LGA ID");listOf(first,last,phone,address,lga).forEach{f.addView(it)}
 f.addView(button("Save"){val body=JSONObject().put("first_name",first.text.toString()).put("last_name",last.text.toString()).put("phone",phone.text.toString()).put("address",address.text.toString()).put("state","Zamfara").put("city","Talata Mafara").put("lga",lga.text.toString().toIntOrNull()).toString()
 ApiClient.post("addresses/",body,t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{toast("Address saved");finish()}};override fun onError(e:String){runOnUiThread{toast(e)}}})});setContentView(f)}
}
