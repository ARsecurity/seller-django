package ng.seller.customer.screens
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import ng.seller.customer.*
import ng.seller.customer.models.Product
import org.json.JSONObject
import java.util.Locale
class ProductDetailActivity:AppCompatActivity(){
    private var product:Product?=null
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_product_detail)
        val id=intent.getIntExtra("product_id",-1);if(id<1){finish();return};findViewById<Button>(R.id.addToCartButton).isEnabled=false
        ApiClient.get("products/$id/",null,object:ApiClient.Callback{
            override fun onSuccess(r:String){runOnUiThread{try{render(JsonParser.product(JSONObject(r)))}catch(e:Exception){toast(e.message);finish()}}}
            override fun onError(e:String){runOnUiThread{toast(e);finish()}}
        })
    }
    private fun render(p:Product){product=p;findViewById<TextView>(R.id.detailProductName).text=p.name
        findViewById<TextView>(R.id.detailProductPrice).text=String.format(Locale.US,"₦%,.0f",p.currentPrice)
        findViewById<TextView>(R.id.detailProductMeta).text="⭐ %.1f (%d reviews) • %d sold".format(p.ratingAvg,p.ratingCount,p.sold)
        findViewById<TextView>(R.id.detailStock).text=if(p.stock>0) "${p.stock} available" else "Out of stock"
        findViewById<TextView>(R.id.detailProductDescription).text=p.description.ifBlank{"No description available."}
        findViewById<TextView>(R.id.detailShopInfo).text=listOfNotNull(p.sourceShopName,p.sourceShopAddress,p.sourceShopPhone?.let{"Phone: $it"},p.sourceShopEmail?.let{"Email: $it"},p.sourceShopDescription).joinToString("\n").ifBlank{"Source shop information unavailable."}
        Glide.with(this).load(p.imageUrl).placeholder(android.R.drawable.ic_menu_gallery).into(findViewById(R.id.detailProductImage))
        findViewById<Button>(R.id.addToCartButton).isEnabled=p.stock>0
        findViewById<Button>(R.id.addToCartButton).setOnClickListener{CartStorage.add(this,p);toast("Added to cart");findViewById<Button>(R.id.addToCartButton).text="Added to Cart"}
        findViewById<Button>(R.id.buyNowButton).setOnClickListener{CartStorage.add(this,p);startActivity(android.content.Intent(this,CartActivity::class.java))}
        findViewById<Button>(R.id.wishlistButton).setOnClickListener{
            val t=SessionStorage.token(this);if(t==null){toast("Login required");startActivity(android.content.Intent(this,LoginActivity::class.java));return@setOnClickListener}
            ApiClient.post("products/${p.id}/wishlist/","{}",t,object:ApiClient.Callback{override fun onSuccess(r:String){runOnUiThread{toast("Wishlist updated")}};override fun onError(e:String){runOnUiThread{toast(e)}}})
        }
    }
    private fun toast(s:String?){Toast.makeText(this,s?:"Error",Toast.LENGTH_LONG).show()}
}
