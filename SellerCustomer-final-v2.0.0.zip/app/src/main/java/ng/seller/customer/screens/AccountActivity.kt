package ng.seller.customer.screens
import android.content.Intent
import android.os.Bundle
import ng.seller.customer.*
import org.json.JSONObject
class AccountActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);render()}
 private fun render(){val r=root("Account");val t=SessionStorage.token(this)
 if(t==null){r.addView(text("You are not logged in"));r.addView(button("Login"){startActivity(Intent(this,LoginActivity::class.java))});r.addView(button("Register"){startActivity(Intent(this,RegisterActivity::class.java))})}
 else{r.addView(text("Loading profile..."));ApiClient.get("me/",t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{val o=JSONObject(x);r.getChildAt(1).let{(it as android.widget.TextView).text="Username: ${o.optString("username")}\nAdmin: ${o.optBoolean("admin")}"} }};override fun onError(e:String){runOnUiThread{toast(e)}}})
 r.addView(text(""));r.addView(button("Addresses"){startActivity(Intent(this,AddressesActivity::class.java))});r.addView(button("Wishlist"){startActivity(Intent(this,WishlistActivity::class.java))});r.addView(button("Notifications"){startActivity(Intent(this,NotificationsActivity::class.java))});r.addView(button("Orders"){startActivity(Intent(this,OrdersActivity::class.java))});r.addView(button("Logout"){SessionStorage.clear(this);finish()})};setContentView(r)}
}
