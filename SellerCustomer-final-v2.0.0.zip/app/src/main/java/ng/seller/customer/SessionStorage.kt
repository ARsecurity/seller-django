package ng.seller.customer
import android.content.Context

object SessionStorage {
    private const val PREF = "seller_session"
    private const val TOKEN = "token"
    fun token(c: Context): String? = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(TOKEN, null)
    fun saveToken(c: Context, token: String) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(TOKEN, token).apply()
    fun clear(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
}
