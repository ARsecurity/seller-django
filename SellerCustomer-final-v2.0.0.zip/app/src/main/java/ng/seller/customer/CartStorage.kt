package ng.seller.customer
import android.content.Context
import ng.seller.customer.models.Product
import org.json.JSONArray
import org.json.JSONObject

object CartStorage {
    private const val PREF = "seller_cart"
    private const val KEY = "items"
    data class Line(val product: Product, var qty: Int)

    private fun loadJson(c: Context): JSONArray =
        JSONArray(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))

    private fun saveJson(c: Context, a: JSONArray) =
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()

    fun items(c: Context): MutableList<Line> {
        val a = loadJson(c); val out = mutableListOf<Line>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Line(JsonParser.product(o.getJSONObject("product")), o.optInt("qty", 1)))
        }
        return out
    }

    fun add(c: Context, p: Product, qty: Int = 1) {
        val a = loadJson(c); var found = false
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optInt("product_id") == p.id) {
                o.put("qty", minOf(p.stock, o.optInt("qty", 1) + qty)); found = true; break
            }
        }
        if (!found) a.put(JSONObject().put("product_id", p.id).put("qty", qty).put("product", JsonParser.productJson(p)))
        saveJson(c, a)
    }

    fun setQty(c: Context, productId: Int, qty: Int) {
        val a = loadJson(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).optInt("product_id") == productId) {
            if (qty <= 0) a.remove(i) else a.getJSONObject(i).put("qty", qty)
            break
        }
        saveJson(c, a)
    }

    fun remove(c: Context, productId: Int) = setQty(c, productId, 0)
    fun clear(c: Context) = saveJson(c, JSONArray())
    fun count(c: Context): Int = items(c).sumOf { it.qty }
}
