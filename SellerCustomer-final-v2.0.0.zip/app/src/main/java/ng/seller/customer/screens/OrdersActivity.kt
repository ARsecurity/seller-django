package ng.seller.customer.screens
import android.content.Intent
import android.os.Bundle
import android.widget.*
import ng.seller.customer.*
import org.json.JSONArray
class OrdersActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);load()}
 private fun load(){val r=root("Orders");val t=SessionStorage.token(this);if(t==null){r.addView(button("Login"){startActivity(Intent(this,LoginActivity::class.java))});setContentView(r);return}
 ApiClient.get("orders/",t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{val a=JSONArray(x);if(a.length()==0)r.addView(text("No orders yet"));for(i in 0 until a.length()){val o=a.getJSONObject(i);val ref=o.optString("ref");r.addView(text("Order $ref\nStatus: ${o.optString("status")}\nTotal: ₦${o.optDouble("total")}",17f));if(o.optString("status")=="PENDING"||o.optString("status")=="AWAITING")r.addView(button("Cancel $ref"){cancel(ref,t)});if(o.optString("status")=="AWAITING")r.addView(button("Submit Payment Proof"){startActivity(Intent(this,ProofActivity::class.java).putExtra("ref",ref))})}}};override fun onError(e:String){runOnUiThread{toast(e)}}});setContentView(r)}
 private fun cancel(ref:String,t:String){ApiClient.post("orders/$ref/cancel/","{}",t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{toast("Order cancelled");load()}};override fun onError(e:String){runOnUiThread{toast(e)}}})}
}
