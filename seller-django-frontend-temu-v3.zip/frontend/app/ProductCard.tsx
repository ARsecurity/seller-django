"use client";
import Link from "next/link";
import {useState} from "react";
import Img from "./Img";
import {Product,api,naira} from "@/lib/api";
import {addToCart,getToken} from "@/lib/store";

export default function ProductCard({p}:{p:Product}){
  const[added,setAdded]=useState(false);
  const[liked,setLiked]=useState(false);
  const toggle=async(e:React.MouseEvent)=>{
    e.preventDefault();e.stopPropagation();
    const t=getToken();
    if(!t){location.href="/login";return}
    try{const r=await api<{wishlisted:boolean}>(`products/${p.id}/wishlist/`,{method:"POST"},t);setLiked(r.wishlisted)}catch{}
  };
  const add=(e:React.MouseEvent)=>{
    e.preventDefault();e.stopPropagation();
    addToCart(p);setAdded(true);setTimeout(()=>setAdded(false),1000);
  };
  const low=p.stock>0&&p.stock<6;
  return <article className="product-card">
    <Link href={`/product/${p.id}`}>
      <div className="product-image-wrap">
        <Img src={p.image_url||p.gallery[0]} alt={p.name}/>
        {low&&<span className="limited-badge">ONLY {p.stock} LEFT</span>}
        {p.discount_pct>0&&<span className="discount">-{p.discount_pct}%</span>}
        <button className="heart-btn" onClick={toggle} aria-label="Add to wishlist">{liked?"♥":"♡"}</button>
      </div>
      <div className="product-body">
        <div className="product-name">{p.name}</div>
        <div className="price-line"><b className="price">{naira(p.current_price)}</b>{p.discount_pct>0&&<s className="old-price">{naira(p.price)}</s>}</div>
        <div className="product-meta">
          {p.rating_count?`★ ${p.rating_avg.toFixed(1)} · `:"New · "}{p.sold} sold
          {low&&<span className="stock"> · {p.stock} left</span>}
        </div>
      </div>
    </Link>
    <div className="product-body product-actions">
      <button className={`add-btn ${added?"filled":""}`} disabled={p.stock<1} onClick={add}>
        {p.stock<1?"Sold out":added?"Added ✓":"Add to cart"}
      </button>
    </div>
  </article>;
}
