package ng.seller.customer.screens
import android.os.Bundle
import ng.seller.customer.*
import org.json.JSONArray
class NotificationsActivity:BaseScreen(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val r=root("Notifications");val t=SessionStorage.token(this);if(t==null){toast("Login required");finish();return}
 ApiClient.get("notifications/",t,object:ApiClient.Callback{override fun onSuccess(x:String){runOnUiThread{val a=JSONArray(x);for(i in 0 until a.length()){val o=a.getJSONObject(i);r.addView(text("${o.optString("title")}\n${o.optString("body")}"))};ApiClient.post("notifications/read/","{}",t,object:ApiClient.Callback{override fun onSuccess(x:String){};override fun onError(e:String){}})}};override fun onError(e:String){runOnUiThread{toast(e)}}});setContentView(r)}
}
