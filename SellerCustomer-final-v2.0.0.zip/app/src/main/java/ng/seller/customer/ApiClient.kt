package ng.seller.customer

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

object ApiClient {
    const val BASE_URL = "https://seller-zamfara-api.onrender.com/api/"
    private val executor = Executors.newCachedThreadPool()

    interface Callback {
        fun onSuccess(response: String)
        fun onError(error: String)
    }

    fun get(path: String, token: String?, callback: Callback) =
        request("GET", path, null, token, callback)

    fun post(path: String, body: String, token: String?, callback: Callback) =
        request("POST", path, body, token, callback)

    fun patch(path: String, body: String, token: String?, callback: Callback) =
        request("PATCH", path, body, token, callback)

    fun delete(path: String, token: String?, callback: Callback) =
        request("DELETE", path, null, token, callback)

    private fun request(method: String, path: String, body: String?, token: String?, callback: Callback) {
        executor.execute {
            var conn: HttpURLConnection? = null
            try {
                conn = URL(BASE_URL + path.trimStart('/')).openConnection() as HttpURLConnection
                conn.requestMethod = method
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                conn.setRequestProperty("Accept", "application/json")
                if (!body.isNullOrEmpty()) {
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.doOutput = true
                    OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
                }
                if (!token.isNullOrBlank()) conn.setRequestProperty("Authorization", "Token $token")
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = BufferedReader(InputStreamReader(stream ?: conn.inputStream)).use { it.readText() }
                if (code in 200..299) callback.onSuccess(text)
                else callback.onError(parseError(code, text))
            } catch (e: Exception) {
                callback.onError(e.message ?: "Network error")
            } finally { conn?.disconnect() }
        }
    }

    private fun parseError(code: Int, text: String): String {
        return try {
            val o = org.json.JSONObject(text)
            when {
                o.has("detail") -> o.optString("detail")
                o.has("error") -> o.optString("error")
                else -> text.ifBlank { "Request failed ($code)" }
            }
        } catch (_: Exception) { text.ifBlank { "Request failed ($code)" } }
    }
}
