package ng.seller.customer
import ng.seller.customer.models.*
import org.json.JSONArray
import org.json.JSONObject

object JsonParser {
    fun home(json:String):HomeResponse {
        val r=JSONObject(json); return HomeResponse(products(r.optJSONArray("deals")),products(r.optJSONArray("trending")))
    }
    private fun products(a:JSONArray?):List<Product> = if(a==null) emptyList() else (0 until a.length()).map{product(a.getJSONObject(it))}
    fun product(o:JSONObject):Product {
        val s=o.optJSONObject("source_shop_info")
        return Product(
            o.optInt("id"),o.optString("name"),o.optString("description"),o.optDouble("price"),
            if(o.isNull("sale_price")) null else o.optDouble("sale_price"),
            o.optDouble("current_price",o.optDouble("price")),o.optString("image_url").takeIf{it.isNotBlank()},
            o.optInt("stock"),o.optInt("sold"),o.optDouble("rating_avg"),o.optInt("rating_count"),
            o.optDouble("discount_pct"),if(o.isNull("category")) null else o.optInt("category"),
            o.optString("shop").takeIf{it.isNotBlank()},
            s?.optString("name")?.takeIf{it.isNotBlank()},s?.optString("address")?.takeIf{it.isNotBlank()},
            s?.optString("phone")?.takeIf{it.isNotBlank()},s?.optString("email")?.takeIf{it.isNotBlank()},
            s?.optString("description")?.takeIf{it.isNotBlank()}
        )
    }
    fun productJson(p:Product)=JSONObject().apply {
        put("id",p.id);put("name",p.name);put("description",p.description);put("price",p.price)
        put("sale_price",p.salePrice ?: JSONObject.NULL);put("current_price",p.currentPrice)
        put("image_url",p.imageUrl ?: "");put("stock",p.stock);put("sold",p.sold);put("rating_avg",p.ratingAvg)
        put("rating_count",p.ratingCount);put("discount_pct",p.discountPct);put("category",p.category ?: JSONObject.NULL)
        put("shop",p.shop ?: "");put("source_shop_info",JSONObject().apply {
            put("name",p.sourceShopName ?: "");put("address",p.sourceShopAddress ?: "")
            put("phone",p.sourceShopPhone ?: "");put("email",p.sourceShopEmail ?: "")
            put("description",p.sourceShopDescription ?: "")
        })
    }
}
